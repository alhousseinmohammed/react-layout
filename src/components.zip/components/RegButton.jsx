import react from 'react';

const RegButton = () => {
  return (
<button className="fill first">Join</button>
  )
}

export default RegButton